from fastapi import FastAPI, Response

from .cars import create_cars

cars = create_cars(100)  # Здесь хранятся список машин
app = FastAPI()


@app.get("/")
def index():
    return Response("<a href='/cars'>Cars</a>")




# (сюда писать решение)


# (конец решения)
