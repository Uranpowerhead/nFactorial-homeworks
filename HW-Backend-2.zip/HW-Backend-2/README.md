# hw-backend-2

Папка для заданий [cars](./cars):
- cars-pagination
- cars-id

Папка для заданий [users](./users):
- users-all
- users-id
- users-pagination 💎
